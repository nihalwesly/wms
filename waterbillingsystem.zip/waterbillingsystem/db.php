<?php
$conn = mysqli_connect('localhost', 'root', '',"waterbilling") or die("Database Connection failed.");
	

